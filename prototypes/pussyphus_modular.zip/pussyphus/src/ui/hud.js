// ════════════════════════════════════════
// HUD — in-game UI overlays
// ════════════════════════════════════════
import * as K from '../constants.js';

let fbar;
const PIP_COUNT = 15;

export function init() {
  fbar = document.getElementById('fbar');
  for (let i = 0; i < PIP_COUNT; i++) {
    const p = document.createElement('div');
    p.className = 'fp';
    fbar.appendChild(p);
  }
}

export function update(flow, alt, npcCount) {
  const fi = Math.min(Math.floor(flow), K.MOODS.length - 1);

  document.getElementById('mt').textContent = 'MOOD: ' + K.MOODS[fi];
  document.getElementById('at').textContent = 'ALT: ' + alt;

  // Flow bar pips
  const pips = fbar.children;
  for (let i = 0; i < pips.length; i++) {
    pips[i].className = 'fp' + (i < flow ? (i > 10 ? ' h' : ' a') : '');
  }

  document.getElementById('ft').textContent = K.FLOW_WORDS[fi];

  // Zone depth
  const zoneNames = ['YOU ARE HERE','ASCENDING','ASCENDING','LEVEL 2','LEVEL 2','DEEP KIOSK','THE CANYON','THE CANYON'];
  document.getElementById('dt').textContent = zoneNames[Math.min(Math.floor(alt / 50), zoneNames.length - 1)];

  // Status bar
  document.getElementById('sb1').textContent = 'scent index: ' + (flow > 5 ? 'elevated' : 'nominal');
  const di = Math.min(Math.floor(npcCount / 3), K.DENSITY_WORDS.length - 1);
  document.getElementById('sb2').textContent = 'social density: ' + K.DENSITY_WORDS[di];
  document.getElementById('sb3').textContent = flow > 12 ? '✧✧✧' : flow > 6 ? '✧✧' : flow > 2 ? '✧' : '☆';
}
